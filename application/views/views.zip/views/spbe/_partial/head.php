    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo SITE_NAME .": ". ucfirst($this->uri->segment(1)) ." - ". ucfirst($this->uri->segment(2)) ?></title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('gentelella/vendors/bootstrap/dist/css/bootstrap.min.css') ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url('gentelella/vendors/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url('gentelella/vendors/nprogress/nprogress.css') ?>" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url('gentelella/vendors/iCheck/skins/flat/green.css') ?>" rel="stylesheet">
	
    <!-- bootstrap-progressbar -->
    <link href="<?php echo base_url('gentelella/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css') ?>" rel="stylesheet">
    <!-- JQVMap -->
    <link href="<?php echo base_url('gentelella/vendors/jqvmap/dist/jqvmap.min.css') ?>" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo base_url('gentelella/vendors/bootstrap-daterangepicker/daterangepicker.css') ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url('gentelella/build/css/custom2.min.css') ?>" rel="stylesheet">

    <script src="<?php echo base_url('gentelella/vendors/jquery/dist/jquery.min.js') ?>"></script>
    <script>
        $(document).ready(function(){
           $(".ada1").click(function(){
                //alert("yeah");
                $('.sisi1').show();
            });
           $(".tidak1").click(function(){
                $('.sisi1').hide();
          });
        });
        $(document).ready(function(){
           $(".ada2").click(function(){
                //alert("yeah");
                $('.sisi2').show();
            });
           $(".tidak2").click(function(){
                $('.sisi2').hide();
          });
        });
        $(document).ready(function(){
           $(".ada3").click(function(){
                //alert("yeah");
                $('.sisi3').show();
            });
           $(".tidak3").click(function(){
                $('.sisi3').hide();
          });
        });
        $(document).ready(function(){
           $(".ada23").click(function(){
                //alert("yeah");
                $('.sisi23').show();
            });
           $(".tidak23").click(function(){
                $('.sisi23').hide();
          });
        });
        $(document).ready(function(){
           $(".ada24").click(function(){
                //alert("yeah");
                $('.sisi24').show();
            });
           $(".tidak24").click(function(){
                $('.sisi24').hide();
          });
        });
         $(document).ready(function(){
           $(".ada31").click(function(){
                //alert("yeah");
                $('.sisi31').show();
            });
           $(".tidak31").click(function(){
                $('.sisi31').hide();
          });
        });
          $(document).ready(function(){
           $(".ada32").click(function(){
                //alert("yeah");
                $('.sisi32').show();
            });
           $(".tidak32").click(function(){
                $('.sisi32').hide();
          });
        });
          $(document).ready(function(){
           $(".ada33").click(function(){
                //alert("yeah");
                $('.sisi33').show();
            });
           $(".tidak33").click(function(){
                $('.sisi33').hide();
          });
        });
          $(document).ready(function(){
           $(".ada34").click(function(){
                //alert("yeah");
                $('.sisi34').show();
            });
           $(".tidak34").click(function(){
                $('.sisi34').hide();
          });
        });
            $(document).ready(function(){
           $(".ada35").click(function(){
                //alert("yeah");
                $('.sisi35').show();
            });
           $(".tidak35").click(function(){
                $('.sisi35').hide();
          });
        });
              $(document).ready(function(){
           $(".ada36").click(function(){
                //alert("yeah");
                $('.sisi36').show();
            });
           $(".tidak36").click(function(){
                $('.sisi36').hide();
          });
        });



    </script>